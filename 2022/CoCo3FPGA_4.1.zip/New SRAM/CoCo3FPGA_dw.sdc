#create_clock -period 20.000 -name CLK50MHZ [get_ports CLK*]
#derive_pll_clocks
#derive_clock_uncertainty
#set_input_delay -fall -clock CLK50MHZ 12 [get_ports RAM0_DATA*]
#set_input_delay -fall -clock CLK50MHZ 12 [get_ports RAM1_DATA*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM0_ADDRESS*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_ADDRESS*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM0_BE*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_BE*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM0_RW*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_RW*]
#set_output_delay -fall -clock CLK50MHZ 1 [get_ports PH_2_RAW]

create_clock -period 20.000 -name CLK50MHZ [get_ports CLK50*]
create_clock -period 41.667 -name CLK24MHZ [get_ports CLK24*]
create_clock -period 279.37 -name CLK35MHZ [get_ports CLK3*]
create_clock -period 80.000 -name PH2_02 [get_ports PH2*]
derive_pll_clocks
derive_clock_uncertainty
# RAM0 mainly for the new SRAM
# Falling edge
set_input_delay -fall -max -clock CLK50MHZ 10 [get_ports RAM0_DATA*]
set_input_delay -fall -min -clock CLK50MHZ 10 [get_ports RAM0_DATA*]
set_output_delay -fall -min -clock CLK50MHZ -0.5 [get_ports RAM0_DATA*]
set_output_delay -fall -max -clock CLK50MHZ -0.5 [get_ports RAM0_DATA*]
set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM0_ADDRESS*]
set_output_delay -fall -clock CLK50MHZ 3 [get_ports RAM0_RW*]
set_output_delay -fall -clock CLK50MHZ 3 [get_ports RAM0_BE*]
# Rising edge
set_input_delay -rise -max -clock CLK50MHZ 10 [get_ports RAM0_DATA*]
set_input_delay -rise -min -clock CLK50MHZ 10 [get_ports RAM0_DATA*]
set_output_delay -rise -min -clock CLK50MHZ -0.5 [get_ports RAM0_DATA*]
set_output_delay -rise -max -clock CLK50MHZ -0.5 [get_ports RAM0_DATA*]
set_output_delay -rise -clock CLK50MHZ 1 [get_ports RAM0_ADDRESS*]
set_output_delay -rise -clock CLK50MHZ 3 [get_ports RAM0_RW*]
set_output_delay -rise -clock CLK50MHZ 3 [get_ports RAM0_BE*]
# RAM1 for the Analog Board
# Falling edge
set_input_delay -fall -clock CLK50MHZ 10 [get_ports RAM1_DATA*]
set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_ADDRESS*]
set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_RW*]
set_output_delay -fall -clock CLK50MHZ 4 [get_ports RAM1_BE*]
# Rising edge
set_input_delay -fall -clock CLK50MHZ 10 [get_ports RAM1_DATA*]
set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_ADDRESS*]
set_output_delay -fall -clock CLK50MHZ 1 [get_ports RAM1_RW*]
set_output_delay -fall -clock CLK50MHZ 4 [get_ports RAM1_BE*]
# System Clock
set_output_delay -fall -clock CLK50MHZ 1 [get_ports PH*]
set_output_delay -rise -clock CLK50MHZ 1 [get_ports PH*]
