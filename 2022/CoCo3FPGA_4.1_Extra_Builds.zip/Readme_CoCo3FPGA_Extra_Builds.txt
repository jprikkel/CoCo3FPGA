CoCo3FPGA Extra Builds Readme

Ed_or_No
DE1 Memory only
No analog board required, but compiled with Ed's Analog board pinout

New_Ed
Compiled with all 5 Meg of memory enabled, but timing is setup for the New SRAM
Ed's Analog board

New_Gary
Compiled with all 5 Meg of memory enabled, but timing is setup for the New SRAM
Gary's Analog board

Old_Gary
Compiled with all 5 Meg of memory enabled, but timing is setup for the Old SRAM
Gary's Analog board
